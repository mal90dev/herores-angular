export interface DialogDataGrid {
  title: string;
  textContent: string;
  buttonTextOk: string;
  buttonTextCancel: string;
}
