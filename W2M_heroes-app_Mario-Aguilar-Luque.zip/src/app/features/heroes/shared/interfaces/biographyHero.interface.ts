export interface BiographyHero {
  fullName: string;
  aliases: string[];
  publisher: string;
}
