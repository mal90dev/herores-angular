export interface AppearanceHero {
  gender: string;
  race: string;
  height: string[];
  weight: string [];
}
