import { Hero } from './hero.interface';

export interface DialogData {
  hero: Hero;
}
