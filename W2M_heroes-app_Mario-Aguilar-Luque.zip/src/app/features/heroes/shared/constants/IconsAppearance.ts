export const IconsAppearance = {
  gender: 'bi-gender-ambiguous',
  height: 'bi-rulers',
  race: 'bi-people-fill',
  weight: 'bi-minecart-loaded',
};
