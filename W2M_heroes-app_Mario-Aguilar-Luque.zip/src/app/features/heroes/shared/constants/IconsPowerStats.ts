
export const IconsPowerStats = {
  combat: 'bi-hammer',
  durability: 'bi-shield-shaded',
  intelligence: 'bi-lightbulb-fill',
  power: 'bi-activity',
  speed: 'bi-lightning-fill',
  strength: 'bi-person-arms-up'
};
